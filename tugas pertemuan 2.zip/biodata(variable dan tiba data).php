<?php
$nama = "Ahmad";
$nim = 2512345678;
$kelas = "3C";
$prodi = "Teknik Informatika";

echo "Nama: ". $nama . "<br>";
echo "Nim: ".  $nim . "<br>";
echo "Kelas: ".  $kelas . "<br>";
echo "Prodi: ".  $prodi ;

?>
