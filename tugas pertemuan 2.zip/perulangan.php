<?php
for ($i = 1; $i <= 10; $i++) {
    echo "perulangan ke -" . $i ."". "<br>";
}
?>
