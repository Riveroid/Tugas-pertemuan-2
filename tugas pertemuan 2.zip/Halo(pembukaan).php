<?php
echo "Hallo, PHP!..";
?>