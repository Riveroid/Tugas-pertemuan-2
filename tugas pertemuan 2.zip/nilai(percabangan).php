<?php

echo"Nilai budi adalah 90". "<br>";

$nilai = 90;
if ($nilai >= 80) {
echo "Sangat Baik";
} elseif ($nilai >= 70) {
echo "Baik";
} else {
echo "Remedial";
}
?>